<?php

namespace App\Controllers;

use App\Models\pesananModel;
use App\Models\daftarpaketModel;



class pesanan extends BaseController
{


    protected $pesananModel;
    public function __construct()
    {
        $this->pesananModel = new pesananModel();
    }

    public function formpesan()
    {
        $data = [
            'tittle' => 'Pesan Paket',
            // 'paket' => $this->daftarpaketModel->getPaket()
        ];

        echo view('pesanan/formpesan', $data);
    }

    public function savepesan()
    {

        $this->pesananModel->save([

            'nama_pemesan' => $this->request->getVar('nama_pemesan'),
            'namapaket' => $this->request->getVar('namapaket'),
            'alamat' => $this->request->getVar('alamat'),
            'email' => $this->request->getVar('email'),
            'nomorhp' => $this->request->getVar('nomorhp'),
            'tgl_konsul' => $this->request->getVar('tgl_konsul'),
            'tgl_pernikahan' => $this->request->getVar('tgl_pernikahan'),
            'pesan' => $this->request->getVar('pesan'),


        ]);
        session()->setFlashdata('pesan', 'data berhasil ditambahkan');
        return redirect()->to('/pesanan/formpesan');
    }


    public function pembayaran()
    {
        $data = [
            'tittle' => 'Metode Pembayaran',
            'formpesanan' => $this->pesananModel->getPesanan(),
            'paket' => $this->daftarpaketModel->getPaket()
        ];

        echo view('pesanan/pembayaran', $data);
    }
}
