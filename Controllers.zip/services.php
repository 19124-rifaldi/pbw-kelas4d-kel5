<?php

namespace App\Controllers;

use App\Models\daftarpaketModel;



class services extends BaseController
{

    // protected $daftarpaketModel;
    // public function __construct()
    // {
    //     $this->daftarpaketModel = new daftarpaketModel();
    // }

    public function services1()
    {
        // $paket = $this->daftarpaketModel->findAll();

        $data = [
            'tittle' => 'Margo Wedding | services',
            'paket' => $this->daftarpaketModel->getPaket()
        ];

        echo view('services/services1', $data);
    }

    public function tampilpaket($slug)
    {
        // $paket=
        // echo $slug;
        

        // // $daftarpaketModel = new daftarpaketModel();
        // // jika paket tidak ada
        // if (empty($data['paket'])) {
        //     throw new \codeIgniter\Exceptions\PageNotFoundException('paket' . $slug . 'tidak ditemukan');
        // }


        // return view('services/tampilpaket', $data);

        // $paket = $this->daftarpaketModel->getPaket($slug);
        $data = [
            'tittle' => 'Margo Wedding | Services',
            'paket' => $this->daftarpaketModel->getPaket($slug)
        ];
        return view('services/tampilpaket',$data);
    }
}
