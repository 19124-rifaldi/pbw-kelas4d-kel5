<?php

namespace App\Controllers;

class css extends BaseController
{

   public function index()
   {
      $this->load->helper('url');
      $this->load->view('test');
   }
}
