<?php

namespace App\Controllers;

use App\Models\daftarpaketModel;

class Pages extends BaseController
{
    public function index()
    {
        $data = [
            'tittle' => 'Margo Wedding'
        ];

        echo view('pages/index', $data);
    }

    

    public function about()
    {
        $data = [
            'tittle' => 'Margo Wedding | about'
        ];

        echo view('pages/about', $data);
    }

    public function gallery()
    {
        $data = [
            'tittle' => 'Margo Wedding | gallery'
        ];

        echo view('pages/gallery', $data);
    }

    public function contact()
    {
        $data = [
            'tittle' => 'Margo Wedding | contact'
        ];

        echo view('pages/contact', $data);
    }


    protected $daftarpaketModel;
    public function __construct()
    {
        $this->daftarpaketModel = new daftarpaketModel();
    }


    
    
}
