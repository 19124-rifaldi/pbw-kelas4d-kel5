<?php

namespace App\Controllers;

use App\Models\daftarpaketModel;

class admin extends BaseController
{
    protected $daftarpaketModel;
    public function __construct()
    {
        $this->daftarpaketModel = new daftarpaketModel();
    }


    public function dashboard()
    {
        $paket = $this->daftarpaketModel->findAll();

        $data = [
            'tittle' => 'Margo Wedding | Ruang Admin',
            'paket' => $paket
        ];

        // $daftarpaketModel = new daftarpaketModel();


        return view('admin/dashboard', $data);
    }

    public function paket()
    {


        $data = [
            'tittle' => 'Margo Wedding | Ruang Admin',
            'paket' => $this->daftarpaketModel->getPaket()
        ];

        // $daftarpaketModel = new daftarpaketModel();


        return view('admin/paket', $data);
    }

    public function listuser()
    {

        $users = new \Myth\Auth\Models\UserModel();
        $data['users'] = $users->findAll();
        $data = [
            'tittle' => 'Margo Wedding | Ruang Admin',
            // 'paket' => $this->daftarpaketModel->getPaket(),
        ];


        // $daftarpaketModel = new daftarpaketModel();


        return view('admin/listuser', $data);
    }

    public function tambahpaket()
    {


        $data = [
            'tittle' => 'Form tambah paket',

        ];

        // $daftarpaketModel = new daftarpaketModel();


        return view('admin/tambahpaket', $data);
    }

    public function save()
    {

        $this->daftarpaketModel->save([

            'slug' => $this->request->getVar('slug'),
            'namapaket' => $this->request->getVar('namapaket'),
            'harga' => $this->request->getVar('harga'),
            'deskbusana' => $this->request->getVar('deskbusana'),
            'deskdekorasi' => $this->request->getVar('deskdekorasi'),
            'deskmakan' => $this->request->getVar('deskmakan'),
            'desktenda' => $this->request->getVar('desktenda'),
            'deskdokumentasi' => $this->request->getVar('deskdokumentasi'),
            'deskadat' => $this->request->getVar('deskadat'),
            'deskinclude' => $this->request->getVar('deskinclude'),
            'deskteam' => $this->request->getVar('deskteam'),
            'deskhiburan' => $this->request->getVar('deskhiburan'),
            'deskprawedding' => $this->request->getVar('deskprawedding')


        ]);
        session()->setFlashdata('pesan', 'data berhasil ditambahkan');

        return redirect()->to('/admin/paket');
    }

    public function delete($idpaket)
    {
        $this->daftarpaketModel->delete($idpaket);
        session()->setFlashdata('pesan', 'data berhasil dihapus');
        return redirect()->to('/admin/paket');
    }

    public function edit($slug)
    {
        $data = [
            'tittle' => 'Form ubah paket',
            'paket'  => $this->daftarpaketModel->getPaket($slug)

        ];

        // $daftarpaketModel = new daftarpaketModel();


        return view('admin/editpaket', $data);
    }

    public function update($idpaket)
    {
        $this->daftarpaketModel->save([
            'idpaket' => $idpaket,
            'slug' => $this->request->getVar('slug'),
            'namapaket' => $this->request->getVar('namapaket'),
            'harga' => $this->request->getVar('harga'),
            'deskbusana' => $this->request->getVar('deskbusana'),
            'deskdekorasi' => $this->request->getVar('deskdekorasi'),
            'deskmakan' => $this->request->getVar('deskmakan'),
            'desktenda' => $this->request->getVar('desktenda'),
            'deskdokumentasi' => $this->request->getVar('deskdokumentasi'),
            'deskadat' => $this->request->getVar('deskadat'),
            'deskinclude' => $this->request->getVar('deskinclude'),
            'deskteam' => $this->request->getVar('deskteam'),
            'deskhiburan' => $this->request->getVar('deskhiburan'),
            'deskprawedding' => $this->request->getVar('deskprawedding')


        ]);
        session()->setFlashdata('pesan', 'data berhasil ditambahkan');

        return redirect()->to('/admin/paket');
    }
}
