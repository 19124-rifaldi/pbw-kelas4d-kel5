<?php

namespace App\Models;

use CodeIgniter\Model;

class listdashboard extends Model
{
    protected $table = 'daftar';
    protected $primaryKey = 'idpesanan';

}
