<?php

namespace App\Models;

use CodeIgniter\Model;

class pesananModel extends Model
{
    protected $table = 'pesanan';
    protected $primaryKey = 'idpesanan';

    protected $allowedFields = [
        'nama_pemesan', 'namapaket', 'alamat', 'email', 'nomorhp', 'tgl_konsul', 'deskmakan', 'tgl_pernikahan', 'pesan'
    ];


    public function getPesanan($namapaket=false)
    {
        if ($namapaket == false) {
            return $this->findAll();
        }

        return $this->where(['namapaket' => $namapaket])->first();
    }
}