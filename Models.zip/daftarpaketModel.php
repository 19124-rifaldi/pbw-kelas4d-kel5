<?php

namespace App\Models;

use CodeIgniter\Model;

class daftarpaketModel extends Model
{
    protected $table = 'daftarpaket';
    protected $primaryKey = 'idpaket';

    protected $allowedFields = [
        'namapaket', 'slug', 'harga', 'deskbusana', 'deskdekorasi', 'deskmakan', 'desktenda', 'deskdokumentasi', 'deskadat', 'deskinclude', 'deskteam', 'deskhiburan', 'deskprawedding'
    ];


    public function getPaket($slug = false)
    {
        if ($slug == false) {
            return $this->findAll();
        }

        return $this->where(['slug' => $slug])->first();
    }
}
