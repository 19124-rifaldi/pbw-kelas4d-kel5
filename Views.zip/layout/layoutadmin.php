<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/css/admin.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('fontawesome/css/all.min.css'); ?>">

    <title><?= $tittle; ?></title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">SELAMAT DATANG ADMIN | <b>MARGO WEDDING</b></a>
        <!-- <form class="form-inline my-2 my-lg-0 ml-auto">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form> -->
        <div class="icon ml-4">
            <h5>
                <!-- <i class="fas fa-envelope mr-3" data-toggle="tooltip" title="Surat Masuk"></i>
                <i class="fas fa-bell mr-3" data-toggle="tooltip" title="Notifikasi"></i> -->
                <!-- <i class="fas fa-sign-out-alt mr-3" data-toggle="tooltip" title="Sign out"></i> -->
            </h5>
            <ul class="nav navbar-nav d-flex justify-content-between mx-xl-5 text-center text-dark">
                <li class="nav-item"><a href="/" class="nav-link btn-outline-primary rounded-pill px-3">menu</a></li>
                <li class="nav-item"><a href="/logout" class="nav-link btn-outline-primary rounded-pill px-3">logout</a></li>
            </ul>


        </div>
        </div>
    </nav>

    <div class="row no-gutters">
        <div class="col-md-2 bg-dark pr-2 pt-4">
            <ul class="nav flex-column ml-3 mb-5">
                <li class="nav-item">
                    <a class="nav-link active text-white" href="<?= base_url('/admin/dashboard'); ?>"><i class="fas fa-tachometer-alt mr-2"></i> Dashboard</a>
                    <hr class="bg-secondary">
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="/admin/listuser"><i class="fas fa-database  mr-2"></i>Users</a>
                    <hr class="bg-secondary">
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link text-white" href="pemesanan.html"><i class="fas fa-shopping-basket  mr-2"></i> Data Pemesanan</a>
                    <hr class="bg-secondary">
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="pembayaran.html"><i class="fas fa-money-check-alt  mr-2"></i> Data Pembayaran</a>
                    <hr class="bg-secondary">
                </li> -->
                <li class="nav-item">
                    <a class="nav-link text-white" href="<?= base_url('/admin/paket'); ?>"><i class="fas fa-clipboard-list  mr-2"></i> Data Paket</a>
                    <hr class="bg-secondary">
                </li>
            </ul>
        </div>


        <?= $this->renderSection('content2'); ?>

        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
        <script type="text/javascript" src="admin.js"></script>

        <!-- Option 2: Separate Popper and Bootstrap JS -->
        <!--
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
    -->
</body>

</html>