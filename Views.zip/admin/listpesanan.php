<?= $this->extend('layout/layoutadmin'); ?>


<?= $this->section('content2'); ?>

<!--card body dashboard-->


<div class="col-md-10 p-5 pt-2">
    <h3><i class="fas fa-clipboard-list  mr-2"></i>Data Pemesanan</h3>
    <hr>
    <div class="card">
        <h5 class="card-header">Data Pesanan Margo Wedding</h5>
        <?php if (session()->getFlashdata('pesan')) : ?>
            <div class="alert alert-success" role="alert">
                <?= session()->getFlashdata('pesan'); ?>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th class="text-center">nama pemesan</th>
                        <th class="text-center">nama paket</th>
                        <th class="text-center">email</th>
                        <th class="text-center">no telepon</th>
                        <th class="text-center">action</th>


                    </tr>
                </thead>
                <tbody>

                    <?php foreach ($pesanan as $p) : ?>
                        <tr>
                            <td class="text-center"><?= $p->nama_pemesan; ?></td>
                            <td class="text-center"><?= $p->namapaket; ?></td>
                            <td class="text-center"><?= $p->email; ?></td>
                            <td class="text-center"><?= $p->nomorhp; ?></td>
                            <td><a href="/admin/deletepesanan/<?= $p->nama_pemesan; ?>" onclick="return confirm('Apakah yakin ingin menghapus data ini?')" class="btn btn-danger">
                                    Hapus</a></td>



                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <!-- //penutup perluangan while  -->

            </table>
        </div>
    </div>
    <?php $this->endSection(); ?>