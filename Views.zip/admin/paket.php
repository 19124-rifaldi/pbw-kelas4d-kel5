<?= $this->extend('layout/layoutadmin'); ?>


<?= $this->section('content2'); ?>

<!--card body dashboard-->
<div class="col-md-10 p-5 pt-2">
    <h3><i class="fas fa-clipboard-list  mr-2"></i> DATA PAKET</h3>
    <hr>
    <div class="card">
        <h5 class="card-header">Data Paket Margo Wedding</h5>
        <?php if (session()->getFlashdata('pesan')) : ?>
            <div class="alert alert-success" role="alert">
                <?= session()->getFlashdata('pesan'); ?>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th class="text-center">idpaket</th>
                        <th class="text-center">Nama Paket</th>
                        <th class="text-center">Harga paket</th>
                        <th>
                            <a class="btn btn-success" href="<?php echo base_url('admin/tambahpaket'); ?>">tambah</a>
                        </th>

                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($paket as $p) : ?>
                        <tr>
                            <td><?= $p['idpaket']; ?></td>
                            <td><?= $p['namapaket']; ?></td>
                            <td><?= $p['harga']; ?></td>

                            <td>
                                <a href="/admin/edit/<?= $p['slug']; ?>" class="btn btn-warning">Edit</a>
                                <!-- <form action="/komik/<?= $p['idpaket']; ?>" class="d-inline" method="POST">
                                    <?= csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                </form> -->
                                <a href="/admin/delete/<?= $p['idpaket']; ?>" onclick="return confirm('Apakah yakin ingin menghapus data ini?')" class="btn btn-danger">
                                    Hapus</a>
                            </td>


                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <!-- //penutup perluangan while  -->

            </table>
        </div>
    </div>
    <?php $this->endSection(); ?>