<?= $this->extend('layout/layoutadmin'); ?>


<?= $this->section('content2'); ?>


    <!--card body dashboard-->
    <div class="col-md-10 p-5 pt-2">
        <h3><i class="fas fa-tachometer-alt mr-2"></i> DASHBOARD</h3>
        <hr>
        <div class="row text-white">
            <div class="card bg-info ml-4" style="width: 18rem;">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fas fa-database  mr-2"></i>
                    </div>
                    <h5 class="card-title">DATA PELANGGAN</h5>
                    <div class="display-4">10</div>
                    <a href="pelanggan.html">
                        <p class="card-text text-white">Lihat Detail <i class="fas fa-angle-double-right ml-2"></i></p>
                    </a>
                </div>
            </div>
            <!--card body pemesanan-->
            <div class="card bg-success ml-4" style="width: 18rem;">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fas fa-shopping-basket  mr-2"></i>
                    </div>
                    <h5 class="card-title">DATA PEMESANAN</h5>
                    <div class="display-4">5</div>
                    <a href="pemesanan.html">
                        <p class="card-text text-white">Lihat Detail <i class="fas fa-angle-double-right ml-2"></i></p>
                    </a>
                </div>
            </div>
            <!--card body pembayaran-->
            <div class="card bg-info ml-4" style="width: 18rem;">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fas fa-money-check-alt  mr-2"></i>
                    </div>
                    <h5 class="card-title">DATA PEMBAYARAN</h5>
                    <div class="display-4">3</div>
                    <a href="pembayaran.html">
                        <p class="card-text text-white">Lihat Detail <i class="fas fa-angle-double-right ml-2"></i></p>
                    </a>
                </div>
            </div>
            <!--card body paket-->
            <div class="card bg-info ml-4" style="width: 18rem;">
                <div class="card-body">
                    <div class="card-body-icon">
                        <i class="fas fa-clipboard-list  mr-2"></i>
                    </div>
                    <h5 class="card-title">DATA PAKET</h5>
                    <div class="display-4">6</div>
                    <a href="paket.html">
                        <p class="card-text text-white">Lihat Detail <i class="fas fa-angle-double-right ml-2"></i></p>
                    </a>
                </div>
            </div>
        </div>

        <div class="row mt-4">

        </div>

        <!--card body sosial media-->
        <div class="row mt-4">
            <div class="card ml-4 text-white text-center" style="width: 18rem;">
                <div class="card-header bg-danger display-4 pt-4 pb-4">
                    <i class="fab fa-instagram"></i>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-danger">INSTAGRAM</h5>
                    <a href="#" class="btn btn-danger">FOLLOW</a>
                </div>
            </div>

            <div class="card ml-4 text-white text-center" style="width: 18rem;">
                <div class="card-header bg-info display-4 pt-4 pb-4">
                    <i class="fab fa-facebook-f"></i>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-info">FACEBOOK</h5>
                    <a href="#" class="btn btn-info">LIKE</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>