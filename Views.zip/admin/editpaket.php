<?= $this->extend('layout/layoutadmin'); ?>


<?= $this->section('content2'); ?>

<div class="col-md-10 p-5 pt-2">
    <h1>ubah data paket</h1>
    <form action="/admin/update/<?= $paket['idpaket']; ?>" class="" method="post">
        <?= csrf_field(); ?>


        <label for="slug">namapaket(menggunakan huruf kecil tanpa spasi)</label>
        <input type="text" class="form-control" name="slug" value="<?= $paket['slug']; ?>">

        <label for="namapaket">Nama Paket</label>
        <input type="text" class="form-control" name="namapaket" value="<?= $paket['namapaket']; ?>">

        <label for="harga">Harga</label>
        <input type="text" class="form-control" name="harga" value="<?= $paket['harga']; ?>">


        <label for="deskbusana">Makeup dan Busana</label><br>
        <textarea name="deskbusana" id="deskbusana" cols="90" rows="5"></textarea><br>

        <label for="deskdekorasi">Dekorasi</label><br>
        <textarea name="deskdekorasi" id="deskdekorasi" cols="90" rows="5"></textarea><br>

        <label for="deskmakan">Perlengkapan Makan</label><br>
        <textarea name="deskmakan" id="deskmakan" cols="90" rows="5"></textarea><br>

        <label for="desktenda">Tenda</label><br>
        <textarea name="desktenda" id="desktenda" cols="90" rows="5"></textarea><br>

        <label for="deskdokumentasi">Dokumentasi</label><br>
        <textarea name="deskdokumentasi" id="deskdokumentasi" cols="90" rows="5"></textarea><br>

        <label for="">Acara adat</label><br>
        <textarea name="deskadat" id="deskadat" cols="90" rows="5"></textarea><br>

        <label for="">Include</label><br>
        <textarea name="deskinclude" id="deskinclude" cols="90" rows="5"></textarea><br>

        <label for="">Team WO</label><br>
        <textarea name="deskteam" id="deskteam" cols="90" rows="5"></textarea><br>

        <label for="">Hiburan/Entertaiment</label><br>
        <textarea name="deskhiburan" id="deskhiburan" cols="90" rows="5"></textarea><br>

        <label for="">Prawedding</label><br>
        <textarea name="deskprawedding" id="deskprawedding" cols="90" rows="5"></textarea><br>

        <button class="btn btn-primary" type="submit" name="save">Ubah</button>
    </form>
</div>


<?php $this->endSection(); ?>