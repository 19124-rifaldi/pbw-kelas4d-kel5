<?= $this->extend('layout/layout'); ?>
<?= $this->section('content'); ?>


<div class="container pb-3">
    <div class="row flex-center mb-0">
        <div class="col-lg-12 text-start">
            <h2 class="fw-bold fs-md-3 "><br><br><br> <?= $paket['namapaket']; ?></h1>
        </div>
    </div>
</div>

<br>

<div class="container">
    <div class="row">
        <div class="col col-2 ">
            <img src="../img/makeup.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Makeup dan Busana</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskbusana']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/garland.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Dekorasi</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskdekorasi']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/tableware.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Perlengkapan Makan</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskmakan']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/tent.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Tenda</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['desktenda']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/insert-picture-icon.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Dokumentasi</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskdokumentasi']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/people.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Acara adat</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskadat']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/add.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Include</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskinclude']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/group.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Team W0</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskteam']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/video.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Hiburan/Entertaiment</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskhiburan']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col col-2">
            <img src="../img/wedding-rings.png" height="60px" width="60px" alt="">
        </div>
        <div class="col border text-start shadow p-3 bg-body rounded">
            <h2 class="fw-bold fs-md-3 ">Prawedding</h2>
            <br>
            <div class="text-start">
                <p><?= $paket['deskprawedding']; ?></p>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
    <h2>Total Harga : <?= $paket['harga']; ?> </h2>
    <br>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6 align-items-center">
            <a href="/pesanan/formpesan" class="btn btn-warning">Pesan</a>
        </div>
    </div>
</div>



<br><br><br><br>
<?= $this->endSection(); ?>