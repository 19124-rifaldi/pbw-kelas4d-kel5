<?= $this->extend('layout/layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('css/style1.css'); ?>">
</head>


<div class="jumbotron jumbotron-fluid" style="background-color: #E7E6E6;">
    <div class="container">
        <div class="login-box">
            <img src="../img/cincin.png">
        </div>
    </div>
</div>

<div class="container">
    <h1 style="margin-top: 100px;">Jenis Paket</h1>
</div><br><br>

<table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nama paket</th>
            <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php foreach ($paket as $p) : ?>

            <tr>
                <th scope="row"><?= $i++; ?></th>
                <td class="h3"><?= $p['namapaket']; ?></td>
                <td>
                    <a href="/services/<?= $p['slug']; ?>" class="btn btn-primary">></a>
                </td>

            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<br><br>



<?= $this->endSection(); ?>