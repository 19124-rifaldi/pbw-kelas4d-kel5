<?= $this->extend('layout/layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
</head>
<br><br><br><br>
<div class="container">
    <h1 class="text-center">Eksklusif 1</h1>
    <div class="container-fluid">

        <div class="row mt-4">

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 1.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 1.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 1.2.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 1.2.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 1.3.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 1.3.jpeg" width="90%" height="90%">
                </a>
            </div>

        </div>
    </div>
</div>

<!-- Membuat gallery 2 -->
<div class="container">
    <h1 class="text-center">Eksklusif 2</h1>
    <div class="container-fluid">

        <div class="row mt-4">

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 2.2.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 2.2.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 2.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 2.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 2.3.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 2.3.jpeg" width="90%" height="90%">
                </a>
            </div>

        </div>

    </div>
</div>

<div class="container">
    <h1 class="text-center">Eksklusif 3</h1>
    <div class="container-fluid">

        <div class="row mt-4">

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 3.2.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 3.2.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 3.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 3.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 3.3.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 3.3.jpeg" width="90%" height="90%">
                </a>
            </div>

        </div>

    </div>
</div>

<div class="container">
    <h1 class="text-center">Eksklusif 4</h1>
    <div class="container-fluid">

        <div class="row mt-4">

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 4.2.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 4.2.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 4.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 4.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 4.3.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/eks 4.3.jpeg" width="90%" height="90%">
                </a>
            </div>

        </div>

    </div>
</div>

<div class="container">

    <h1 class="text-center">Lily</h1>
    <div class="container-fluid">

        <div class="row mt-4">

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/lily 1.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/lily 1.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/lily 2.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/lily 2.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/lily 3.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/lily 3.jpeg" width="90%" height="90%">
                </a>
            </div>

        </div>

    </div>
</div>

<div class="container">
    <h1 class="text-center">Asoka</h1>
    <div class="container-fluid">

        <div class="row mt-4">

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/asoka 1.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/asoka 1.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/eks 4.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/asoka 2.jpeg" width="90%" height="90%">
                </a>
            </div>

            <div class="item col-sm-6 col-md-4 mb-3">
                <a href="../img/asoka 3.jpeg" class="fancybox" data-fancybox="gallery">
                    <img src="../img/asoka 3.jpeg" width="90%" height="90%">
                </a>
            </div>

        </div>
    </div>
</div>

<?= $this->endSection(); ?>