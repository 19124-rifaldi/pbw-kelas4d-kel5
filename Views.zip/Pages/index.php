<?= $this->extend('layout/layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('css/style.css'); ?>">
</head>
<div class="jumbotron">
    <div class="container">
        <br>
        <br>
        <br>
        <br>
        <br>
        <h1 class="display-4" style="margin-top: 200px;">Creating <br> Unforgettable <br> Memories</h1>
        <hr class="my-4">
        <p>Bersama Margo Wedding Wujudkan Pernikahan Impian</p>

    </div>
</div>
<section class="service-wrapper py-3">
    <div class="container-fluid">
        <div class="row">
            <h2 class="h2 text-center col-12 semi-bold-600 pt-2">Services</h2>
            <div class="service-header col-2 col-lg-3 text-end light-300">
                <i class='bx bx-gift h3 mt-1'></i>
            </div>
            <div class="col-sm-6 pb-3">
                <div class="card bg-white shadow">
                    <div class="card-body">
                        <p class="card-text">Lihat dan pastikan paket wedding apa yang akan kalian pilih</p>
                        <p class="card-text">kalian dapat melihat beberapa paket yang kami berikan beserta harganya.</p>
                        <p class="card-text">Dan jadikan pernikahan kalian menjadi pernikahan yang diimpikan</p>
                        <a href="<?= base_url('/services'); ?>" class="btn">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="card-group">
    <div class="card">
        <img src="./img/Slide1.png" class="card-img-top" alt="...">
    </div>
    <div class="card">
        <img src="./img/slide6.jpeg" class="card-img-top" alt="...">
        <div class="card-body">
        </div>
    </div>
    <div class="card">
        <img src="./img/slide5.jpeg" class="card-img-top" alt="...">
    </div>
</div>

<section class="service-wrapper py-3">
    <div class="container-fluid pb-3">
        <div class="row" style="margin-top: 100px;">
            <h2 class="h2 text-center col-12 py-5 semi-bold-600">Gallery</h2>
            <div class="service-header col-2 col-lg-3 text-end light-300">
                <i class='bx bx-gift h3 mt-1'></i>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="row" style="margin-top: 0px;">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <img src="./img/Dekorasi-Pelaminan-Outdoor-Rustic.png" width="60%" class="img-fluid">
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card" style="background: rgba(175, 148, 80, 0.99); margin-top: 70px; width: 400px;">
                    <div class="card-body">
                        <h5 class="card-title">Gallery</h5>
                        <div class="cb">
                            <img src="./img/flower-31440_960_720.png" class="img-fluid satu">
                        </div>
                        <p class="card-text" style="text-align: center;">Potongan Kenangan</p>
                        <a href="<?= base_url('/pages/gallery'); ?>" class="btn bg-white">Yuk Dilihat</a>
                    </div>
                </div>
            </div>
        </div>
</section>

<?= $this->endSection(); ?>