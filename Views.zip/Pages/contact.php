<?= $this->extend('layout/layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?= base_url('/css/style3.css'); ?>">
</head>

<div class="jumbotron">
    <div class="container">
        <br>
        <br>
        <h1 class="display-4 h2 pb-3 text-primary " style="margin-top: 200px;">Contact</h1>

        <p>Bersama Margo Wedding Wujudkan Pernikahan Impian</p>


    </div>
</div>

<!-- Start Contact -->
<section class="container py-5">

    <div class="row pb-4">
        <div class="col-lg-4">

            <div class="contact row mb-4">
                <ul class="contact-info list-unstyled col-lg-9 col-9  light-300">
                    <li class="h4 mb-0">Hubungi Kami Kapanpun!</li>
                    <li class="h4 mb-0 mt-4">Contact Us</li>
                </ul>
            </div>

            <div class="contact row mb-4">
                <div class="contact-icon col-lg-3 col-3">
                    <div class="py-3 mb-2 text-center border rounded text-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-geo-alt" viewBox="0 0 16 16">
                            <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A31.493 31.493 0 0 1 8 14.58a31.481 31.481 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94zM8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10z" />
                            <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                        </svg>
                    </div>
                </div>
                <ul class="contact-info list-unstyled col-lg-9 col-9  light-300">
                    <li class="h5 mb-0">Alamat</li>
                    <li class="text-muted">jl Rawamangun 3 No.27
                        Pulogadung, Jakarta Timur</li>
                </ul>
            </div>

            <div class="contact row mb-4">
                <div class="contact-icon col-lg-3 col-3">
                    <div class="border py-3 mb-2 text-center border rounded text-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-book" viewBox="0 0 16 16">
                            <path d="M1 2.828c.885-.37 2.154-.769 3.388-.893 1.33-.134 2.458.063 3.112.752v9.746c-.935-.53-2.12-.603-3.213-.493-1.18.12-2.37.461-3.287.811V2.828zm7.5-.141c.654-.689 1.782-.886 3.112-.752 1.234.124 2.503.523 3.388.893v9.923c-.918-.35-2.107-.692-3.287-.81-1.094-.111-2.278-.039-3.213.492V2.687zM8 1.783C7.015.936 5.587.81 4.287.94c-1.514.153-3.042.672-3.994 1.105A.5.5 0 0 0 0 2.5v11a.5.5 0 0 0 .707.455c.882-.4 2.303-.881 3.68-1.02 1.409-.142 2.59.087 3.223.877a.5.5 0 0 0 .78 0c.633-.79 1.814-1.019 3.222-.877 1.378.139 2.8.62 3.681 1.02A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.293-.455c-.952-.433-2.48-.952-3.994-1.105C10.413.809 8.985.936 8 1.783z" />
                        </svg>
                    </div>
                </div>
                <ul class="contact-info list-unstyled col-lg-9 col-9 light-300">
                    <li class="h5 mb-0">Telepon dan Fax</li>
                    <li class="text-muted">Tel : 089827725371</li>
                    <li class="text-muted">Fax : 973927373</li>
                    <li class="text-muted">MargoWedding@gmail.com</li>
                </ul>
            </div>

        </div>


        <!-- Start Contact Form -->
        <div class="col-lg-8 ">
            <form class="contact-form row" method="post" action="#" role="form">

                <div class="col-lg-6 mb-4">
                    <div class="form-floating">
                        <input type="text" class="form-control form-control-lg light-300" id="floatingname" name="inputname" placeholder="Name">
                        <label for="floatingname light-300">Name</label>
                    </div>
                </div><!-- End Input Name -->

                <div class="col-lg-6 mb-4">
                    <div class="form-floating">
                        <input type="text" class="form-control form-control-lg light-300" id="floatingemail" name="inputemail" placeholder="Email">
                        <label for="floatingemail light-300">Email</label>
                    </div>
                </div><!-- End Input Email -->

                <div class="col-lg-6 mb-4">
                    <div class="form-floating">
                        <input type="text" class="form-control form-control-lg light-300" id="floatingphone" name="inputphone" placeholder="Phone">
                        <label for="floatingphone light-300">Phone</label>
                    </div>
                </div><!-- End Input Phone -->

                <div class="col-lg-6 mb-4">
                    <div class="form-floating">
                        <input type="text" class="form-control form-control-lg light-300" id="floatingcompany" name="inputcompany" placeholder="Company Name">
                        <label for="floatingcompany light-300">Company Name</label>
                    </div>
                </div><!-- End Input Company Name -->

                <div class="col-12">
                    <div class="form-floating mb-4">
                        <input type="text" class="form-control form-control-lg light-300" id="floatingsubject" name="inputsubject" placeholder="Subject">
                        <label for="floatingsubject light-300">Subject</label>
                    </div>
                </div><!-- End Input Subject -->

                <div class="col-12">
                    <div class="form-floating mb-3">
                        <textarea class="form-control light-300" rows="8" placeholder="Message" id="floatingtextarea"></textarea>
                        <label for="floatingtextarea light-300">Message</label>
                    </div>
                </div><!-- End Textarea Message -->

                <div class="col-md-12 col-12 m-auto text-end">
                    <button type="submit" class="btn btn-secondary rounded-pill px-md-5 px-4 py-2 radius-0 text-light light-300">Send Message</button>
                </div>

            </form>
        </div>
        <!-- End Contact Form -->


    </div>
</section>

<?= $this->endSection(); ?>