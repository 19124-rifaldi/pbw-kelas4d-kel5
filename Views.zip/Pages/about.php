<?= $this->extend('layout/layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?= base_url('/css/style2.css'); ?>">
</head>
<div class="jumbotron">
    <div class="container">
        <br>
        <h1 class="display-4" style="margin-top:200px;">About Us</h1>
        <div class="box">
            <p>
                Margo wedding merupakan suatu jasa yang bertujuan untuk mempermudah bagi seseorang yang ingin merencanakan impian pernikahannya.
            </p>
        </div>
    </div>
</div>

<section class="container py-5" style="margin-top: 150px;">
    <div class="pt-5 pb-3 d-lg-flex align-items-center gx-5">

        <div class="col-lg-3">
            <h2 class="h2 py-5 typo-space-line">Our Team</h2>
            <hr>
            <p class="text-muted light-300">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
        </div>

        <div class="col-lg-9 row">
            <div class="team-member col-md-4">
                <img class="team-member-img img-fluid rounded-circle p-4" src="../img/rifaldi.jpg" alt="Card image">
                <ul class="nama text-center">
                    <p>Rifaldi Febrianto</p>
                    <p>1910631170124</p>
                </ul>
            </div>
            <div class="team-member col-md-4">
                <img class="team-member-img img-fluid rounded-circle p-4" src="../img/Rida.jpeg" alt="Card image">
                <ul class="nama1 text-center">
                    <p>Rida Armeilia</p>
                    <p>1910631170124</p>
                </ul>
            </div>
            <div class="team-member col-md-4">
                <img class="team-member-img img-fluid rounded-circle p-4" src="../img/IMG_6933.jpg" alt="Card image">
                <ul class="nama1 text-center">
                    <p>Tiara Destiana</p>
                    <p>1910631170237</p>
                </ul>
            </div>
            <div class="team-member col-md-4">
                <img class="team-member-img img-fluid rounded-circle p-4" src="../img/wahyu.jpeg" alt="Card image">
                <ul class="nama1 text-center">
                    <p>Wahyu Darajat</p>
                    <p>1910631170239</p>
                </ul>
            </div>
        </div>

    </div>
</section>

<?= $this->endSection(); ?>