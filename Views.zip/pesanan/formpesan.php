<?= $this->extend('layout/layout'); ?>
<?= $this->section('content'); ?>

<br><br><br><br>
<div class="container-fluid">
    <div class="row">

        <div class="col col-8" id="form">

            <div class="card-header" style="background-color: rgba(175, 148, 80, 0.99);">
                <h5 class="bold">Form Pemesanan </h5>
            </div>
            <?php if (session()->getFlashdata('pesan')) : ?>
                <div class="alert alert-success" role="alert">
                    <?= session()->getFlashdata('pesan'); ?>
                </div>
            <?php endif; ?>
            <form method="post" action="/pesanan/savepesan">
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nama_pemesan" placeholder="Nama Lengkap" class="form-control" placeholder="Input Nama anda disini!" required="">
                </div>

                <div class="form-group">
                    <label>Nama Paket</label>
                    <input type="text" name="namapaket" placeholder="Nama Paket" class="form-control" placeholder="" value="" required="">
                </div>


                <div class="form-group mt-3">
                    <label>Alamat</label>
                    <textarea class="form-control" name="alamat" placeholder="Input alamat anda disini"></textarea>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="text" name="email" placeholder="Email anda" class="form-control" placeholder="Input Email anda disini!" required="">
                </div>

                <div class="form-group mt-3">
                    <label>HP/Ponsel</label>
                    <input type="text" name="nomorhp" placeholder="No. Handphone" class="form-control" placeholder="Input nomor anda disini!" required="">
                </div>

                <div class="form-group mt-3">
                    <label>Tanggal Konsultasi</label>
                    <input type="date" name="tgl_konsul" placeholder="Tanggal Lahir" class="form-control" placeholder="Input tanggal konsultasi anda disini!" required="">
                </div>

                <div class="form-group mt-3">
                    <label>Tanggal Pernikahan</label>
                    <input type="date" name="tgl_pernikahan" placeholder="Tanggal Lahir" class="form-control" placeholder="Input tanggal pernikahan anda disini!" required="">
                </div>

                <div class="form-group mt-3">
                    <label>Pesan mu</label>
                    <textarea class="form-control" name="pesan" placeholder="Input Pesan anda"></textarea>
                </div>

                <button type="submit" class="btn btn-success mt-3">Simpan</button>

                <button type="reset" class="btn btn-danger mt-3" name="breset">Kosongkan</button>
                <br>

            </form>
        </div>



        <div class="col col-4 " style="margin-top: 15%;" id="bayar">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title">Step Selanjutnya</h5>
                    <p class="card-text">Anda harus membayar terlebih dahulu</p>
                    <p>untuk proses selanjutnya, silahkan klik tombol Bayarkan!</p>
                </div>
                <br>
                <a href="/pesanan/pembayaran" class="btn ml-2" style="background-color: rgba(175, 148, 80, 0.99) ;">Bayarkan</a>
            </div>
        </div>

    </div>
</div>
<br><br><br>

<?= $this->endSection(); ?>