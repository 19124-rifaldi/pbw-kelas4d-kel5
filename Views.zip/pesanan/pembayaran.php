<?= $this->extend('layout/layoutbayar'); ?>
<?= $this->section('content'); ?>
<br><br><br><br><br>
<div class="container mt-2" style="margin-top: 200px;">

    <div class="form-floating mt-4 mb-3">
        <input type="input" class="form-control" id="floatingNama" placeholder="" value="">
        <label for="floatingNama">Nama Customer</label>

    </div>
    <div class="form-floating mb-3">
        <input type="input" class="form-control" id="floatingPaket" placeholder="" value="">
        <label for="floatingPaket">Paket</label>
    </div>

    <div class="form-floating mb-3">
        <input type="input" class="form-control" id="floatingTotal" placeholder="Total" value="">
        <label for="floatingPassword">Total</label>
    </div>

    <select class="form-select" aria-label="Default select example">
        <option selected>Pilih Motode Pembayaran</option>
        <option value="1">Bank Virtual Account</option>
        <option value="2">Credit Card</option>
    </select>

    <div class="form-check mt-4">
        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
        <label class="form-check-label" for="flexRadioDefault1">
            Dp
        </label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
        <label class="form-check-label" for="flexRadioDefault2">
            Lunas
        </label>
    </div><br>

    <a href="" class="btn btn-warning" style="margin-right: auto;">Konfirmasi Pembayaran</a>

</div>
<?= $this->endSection(); ?>